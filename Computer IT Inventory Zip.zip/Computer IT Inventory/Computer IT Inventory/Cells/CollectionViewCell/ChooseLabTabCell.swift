//
//  ChooseLabTabCell.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class ChooseLabTabCell: UICollectionViewCell {
    @IBOutlet weak var chooseLab: UIView!
    
    @IBOutlet weak var labName: UILabel!
}
