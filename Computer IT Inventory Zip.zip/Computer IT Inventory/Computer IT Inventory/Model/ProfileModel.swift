//
//  ProfileModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
struct ProfileModel: Codable {
    let status: Bool
    let message: String
    let data: ProfileClass
}

// MARK: - DataClass
struct ProfileClass: Codable {
    let id, name, username, password: String
    let type, status: String
}
