//
//  IssuesCompletedModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 19/10/23.
//

import Foundation

// MARK: - Welcome
struct IssuesCompletedModel: Codable {
    let status: Bool
    let message: String
    let data: [issueStatusCompleted]
}

// MARK: - Datum
struct issueStatusCompleted: Codable {
    let itemID, isssueDate, status, dateOfCompletion: String

    enum CodingKeys: String, CodingKey {
        case itemID = "Item ID"
        case isssueDate = "Isssue Date"
        case status = "Status"
        case dateOfCompletion = "Date of Completion"
    }
}
