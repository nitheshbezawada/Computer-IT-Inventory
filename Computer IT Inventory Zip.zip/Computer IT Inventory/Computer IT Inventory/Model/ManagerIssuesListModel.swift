//
//  ManagerIssuesListModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 27/10/23.

import Foundation

// MARK: - Welcome
struct ManagerIssueModel : Codable {
    let status: Bool
    let message: String
    let data: [ManagerIssueData]
}

// MARK: - Datum
struct ManagerIssueData: Codable {
    let itemID, isssueDate: String

    enum CodingKeys: String, CodingKey {
        case itemID = "Item ID"
        case isssueDate = "Isssue Date"
    }
}
