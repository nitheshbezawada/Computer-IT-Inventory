//
//  SelectTechModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 27/10/23.
//

import Foundation

// MARK: - Welcome
struct SelectTechModel: Codable {
    let status: Bool
    let message: String
    let data: [Tech]
}

// MARK: - Datum
struct Tech: Codable {
    let firstName: String

    enum CodingKeys: String, CodingKey {
        case firstName = "First Name"
    }
}
