//
//  LoginModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 11/10/23.
//

// MARK: - Welcome
struct LoginModel: Codable {
    var status: Bool?
    var message: String?
    var data: LoginData?
}

// MARK: - DataClass
struct LoginData: Codable {
    var id, name, username, password: String?
    var type, status: String?
}
