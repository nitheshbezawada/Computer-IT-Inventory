//
//  TechStatusModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 27/10/23.
//

import Foundation

// MARK: - Welcome
struct TechStatusModel: Codable {
    let status: Bool
    let message: String
    let data: [Techstatus]
}

// MARK: - Datum
struct Techstatus: Codable {
    let memberID, itemID, issueDate, timeLimit: String
    let status: String

    enum CodingKeys: String, CodingKey {
        case memberID = "Member ID"
        case itemID = "Item ID"
        case issueDate = "Issue Date"
        case timeLimit = "Time Limit"
        case status = "Status"
    }
}
