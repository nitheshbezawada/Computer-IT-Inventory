//
//  EditProfileModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 30/10/23.
//

import Foundation

// MARK: - Welcome
struct EditProfileModel: Codable {
    let success: Bool
    let message: String
}
