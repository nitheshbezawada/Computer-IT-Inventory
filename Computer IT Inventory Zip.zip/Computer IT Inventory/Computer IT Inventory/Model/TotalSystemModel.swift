//
//  TotalSystemModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 17/10/23.
//

import Foundation

// MARK: - Welcome
struct TotalSystemModel: Codable {
    let status: Bool
    let message: String
    let data: [detail]
}

// MARK: - Datum
struct detail: Codable {
    let model, category, brand: String

    enum CodingKeys: String, CodingKey {
        case model = "Model"
        case category = "Category"
        case brand = "Brand"
    }
}
