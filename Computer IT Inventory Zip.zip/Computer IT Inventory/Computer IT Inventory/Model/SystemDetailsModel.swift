//
//  SystemDetailsModel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 17/10/23.
//

import Foundation

struct SystemDetailsModel: Codable {
    let status: Bool
    let message: String
    let data: [details]
}

// MARK: - Datum
struct details: Codable {
    let model, category, brand, quantity: String
    let status: String
    let type: typesEnum
    let price, photo: String

    enum CodingKeys: String, CodingKey {
        case model = "Model"
        case category = "Category"
        case brand = "Brand"
        case quantity = "Quantity"
        case status = "Status"
        case type = "Type"
        case price = "Price"
        case photo = "Photo"
    }
}

enum typesEnum: String, Codable {
    case consumable = "Consumable"
}
