//
//  SystemDetailsVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class SystemDetailsVC: UIViewController {
  
    @IBOutlet weak var sysImage: UIImageView!
    @IBOutlet weak var menu: UIImageView!
    @IBOutlet weak var systemDetailsTitleLabel: UILabel!
    @IBOutlet weak var Model: UILabel!
    @IBOutlet weak var Category: UILabel!
    @IBOutlet weak var Brand: UILabel!
    @IBOutlet weak var Quantity: UILabel!
    @IBOutlet weak var Status: UILabel!
    @IBOutlet weak var Price: UILabel!
    
    var apiURL = ""
    var detailsSystem: details?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let ImageName = UserDefaults.standard.string(forKey: "ImageName") ?? ""

        self.Model.text = detailsSystem?.model
        self.Category.text = detailsSystem?.category
        self.Brand.text = detailsSystem?.brand
        self.Quantity.text = detailsSystem?.quantity
        self.Status.text = detailsSystem?.status
        self.Price.text = detailsSystem?.price
        
        self.sysImage.image = UIImage(named: ImageName)
        
        self.menuAction()
        self.systemDetailsTitleLabel.layer.cornerRadius = 20
        self.systemDetailsTitleLabel.layer.masksToBounds = true
        
    }
     
    func menuAction(){
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
    @IBAction func doneAc(_ sender: Any) {
        let selectUser =  UserDefaults.standard.string(forKey: "selectUser")
         if selectUser == "EquipManager" {
             let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
             self.navigationController?.pushViewController(nextVC, animated: true)
         }
         else if selectUser == "Manager" {
             
             let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
             self.navigationController?.pushViewController(nextVC, animated: true)
         }
    }
}
