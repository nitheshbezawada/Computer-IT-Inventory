//
//  SystemDataVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class SystemDataVC: UIViewController {

    @IBOutlet weak var menu: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }

    }
    
    @IBAction func nextAc(_ sender: Any) {
        
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "TotalSystemVC") as! TotalSystemVC
        
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
}
