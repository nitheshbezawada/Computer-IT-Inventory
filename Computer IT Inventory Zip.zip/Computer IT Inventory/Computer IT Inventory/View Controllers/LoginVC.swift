//
//  LoginVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 27/09/23.
//

import UIKit

class LoginVC: UIViewController {

    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var usernameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
   
    var loginDetails: LoginModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        back.addAction(for: .tap) {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func signUp(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    @IBAction func forgotAc(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ForgotPasswordVC") as! ForgotPasswordVC
        self.navigationController?.pushViewController(nextVC, animated: true)
    }
    
    @IBAction func loginAc(_ sender: Any) {
        
        self.GetAPI()
        
//        func  getLoginAPI(){
//
//       let selectUser =  UserDefaults.standard.string(forKey: "selectUser")
//        if selectUser == "EquipManager" {
//            UserDefaultsManager.shared.saveUserId(self.loginDetails.data?.username ?? "")
//            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
//            self.navigationController?.pushViewController(nextVC, animated: true)
//        }
//        else if selectUser == "Manager" {
//            UserDefaultsManager.shared.saveUserId(self.loginDetails.data?.username ?? "")
//            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
//            self.navigationController?.pushViewController(nextVC, animated: true)
//        }
//
//    }




    
}
    func GetAPI(){
        let apiURL = APIList().urlString(url: .logInGet) + "username=\(usernameTF.text ?? "")&password=\(passwordTF.text ?? "")"
        print(apiURL)
           APIHandler().getAPIValues(type: LoginModel.self, apiUrl: apiURL, method: "GET") {  result in
               switch result {
               case .success(let data):
                   self.loginDetails = data
                 print(data)
                   let userId = self.loginDetails.data?.id
                   UserDefaultsManager.shared.saveUserId(userId ?? "")

                   if self.loginDetails.data?.type == "2" {
                       UserDefaultsManager.shared.saveUserId(self.loginDetails.data?.username ?? "")
                       UserDefaults.standard.set(self.loginDetails.data?.type, forKey: "Usertype")
                       DispatchQueue.main.async {
                           let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
                           self.navigationController?.pushViewController(nextVC, animated: true)
                      }
                       
                   }
                   else if self.loginDetails.data?.type == "1"{
                       UserDefaultsManager.shared.saveUserId(self.loginDetails.data?.username ?? "")
                       UserDefaults.standard.set(self.loginDetails.data?.type, forKey: "Usertype")

                       DispatchQueue.main.async {
                           let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
                           self.navigationController?.pushViewController(nextVC, animated: true)
                       }
                   }
                   case .failure(let error):
                   print(error)
                   DispatchQueue.main.async {

                   let alert = UIAlertController(title: "Warrning", message: "Incorrect Password or ID", preferredStyle: .alert)
                   alert.addAction(UIAlertAction(title: "Ok", style: .destructive) { ok in
                       print("JSON Error")
                   })
                   self.present(alert, animated: true, completion: nil)
                   }
               }


       }

            }
}
