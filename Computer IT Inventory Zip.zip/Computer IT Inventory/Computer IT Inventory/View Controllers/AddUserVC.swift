//
//  AddUser.swift
//  Computer IT Inventory
//
//  Created by SAIL on 12/10/23.
//

import UIKit

class AddUserVC: UIViewController {
    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var UsernameTextField: UITextField!
    @IBOutlet weak var PasswordTextField: UITextField!
    @IBOutlet weak var UsertypeTextField: UITextField!
    

    @IBOutlet weak var adduser: UIButton!
    
    var addUser : AddUserModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
//        adduser.addAction(for: .tap) {
//            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
//            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
        func AddUserPostAPI(){
        
               let parameters:[String : String] = [
                   "name": NameTextField.text ?? "" , "username":UsernameTextField.text ?? "" , "password":PasswordTextField.text ?? ""]
               APIHandler().postAPIValues(type:AddUserModel.self,apiUrl: APIList().urlString(url: .AddUser), method: "POST", formData: parameters) { Result in
                   switch Result {
                    case .success(let Data):
                        print(Data)
                       DispatchQueue.main.async { [self] in
                            self.adduser.addAction(for: .tap) {
                          let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC")as!ChooselabVC;
                         self.navigationController?.pushViewController(nextvc, animated: true)
                        }
                        }
                   case .failure(let error):
                       print(error)
                    }
                }
            }
      

    
    
    @IBAction func Done(_ sender: Any) {
        AddUserPostAPI()
    }
    

}
