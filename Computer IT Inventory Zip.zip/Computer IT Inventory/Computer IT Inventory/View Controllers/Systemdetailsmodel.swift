//
//  Systemdetailsmodel.swift
//  Computer IT Inventory
//
//  Created by SAIL on 13/10/23.
//

import Foundation

// MARK: - Welcome
struct Welcome: Codable {
    let status: Bool
    let message: String
    let data: [Datum]
}

// MARK: - Datum
struct Datum: Codable {
    let model, category, brand, quantity: String
    let status: String
    let type: TypeEnum
    let price, photo: String

    enum CodingKeys: String, CodingKey {
        case model = "Model"
        case category = "Category"
        case brand = "Brand"
        case quantity = "Quantity"
        case status = "Status"
        case type = "Type"
        case price = "Price"
        case photo = "Photo"
    }
}

enum TypeEnum: String, Codable {
    case consumable = "Consumable"
}
