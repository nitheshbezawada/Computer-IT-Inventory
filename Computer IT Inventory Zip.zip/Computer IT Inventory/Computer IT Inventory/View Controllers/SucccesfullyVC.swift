//
//  SucccesfullyVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class SucccesfullyVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    override func viewDidDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }

    @IBAction func doneAc(_ sender: Any) {
        let selectUser =  UserDefaults.standard.string(forKey: "selectUser")
         if selectUser == "EquipManager" {
             let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
             self.navigationController?.pushViewController(nextVC, animated: true)
         }
         else if selectUser == "Manager" {
             
             let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ChooselabVC") as! ChooselabVC
             self.navigationController?.pushViewController(nextVC, animated: true)
         }
    }
}
