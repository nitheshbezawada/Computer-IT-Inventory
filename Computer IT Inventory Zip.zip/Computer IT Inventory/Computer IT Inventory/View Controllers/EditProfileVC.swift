//
//  EditProfileVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class EditProfileVC: UIViewController {

    @IBOutlet weak var NameTextField: UITextField!
    @IBOutlet weak var UsernameTextField: UITextField!
    @IBOutlet weak var TypeTextField: UITextField!
    
    var editProfile : EditProfileModel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    func EditProfilePostAPI(){
    
           let parameters:[String : String] = [
               "name": NameTextField.text ?? "" , "username":UsernameTextField.text ?? "" , "type":TypeTextField.text ?? ""]
           APIHandler().postAPIValues(type:EditProfileModel.self,apiUrl:APIList().urlString(url: .EditProfile), method: "POST", formData: parameters) { Result in
               switch Result {
                case .success(let Data):
                    print(Data)
                    DispatchQueue.main.async {
                      let nextvc=UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SucccesfullyVC")as!SucccesfullyVC;
                     self.navigationController?.pushViewController(nextvc, animated: true)
                    }
               case .failure(let error):
                   print(error)
                }
            }
        }
    
    
    @IBAction func save(_ sender: Any) {
        let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
        self.navigationController?.pushViewController(nextVC, animated: true)
         
    }
    

}
