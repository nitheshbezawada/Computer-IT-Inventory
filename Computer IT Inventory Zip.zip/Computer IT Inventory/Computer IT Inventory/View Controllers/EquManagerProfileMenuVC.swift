//
//  EquManagerProfileMenuVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class EquManagerProfileMenuVC: UIViewController {

    @IBOutlet weak var logout: UIImageView!
    @IBOutlet weak var profile: UIImageView!
    @IBOutlet weak var issueStatus: UIImageView!
    @IBOutlet weak var raiseIssue: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        raiseIssue.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "RaiseIssueVC") as! RaiseIssueVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        issueStatus.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquipmentMangerIssuesVC") as! EquipmentMangerIssuesVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        profile.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ProfileVC") as! ProfileVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        logout.addAction(for: .tap) {
            let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "SelectUserVC") as! SelectUserVC
            self.navigationController?.pushViewController(nextVC, animated: true)
        }
        
    }
    

}
