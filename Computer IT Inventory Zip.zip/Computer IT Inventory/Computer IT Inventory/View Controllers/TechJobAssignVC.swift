//
//  TechJobAssignVC.swift
//  Computer IT Inventory
//
//  Created by SAIL on 28/09/23.
//

import UIKit

class TechJobAssignVC: UIViewController {

    @IBOutlet weak var menu: UIImageView!
    @IBOutlet weak var Tableview: UITableView!{
        didSet{
            Tableview.dataSource = self
            Tableview.delegate = self
        }
    }
    
    var techStatus : TechStatusModel?

    override func viewDidLoad() {
        super.viewDidLoad()
        TechStatusAPI()
        menu.addAction(for: .tap) {
            let userType = UserDefaults.standard.string(forKey: "Usertype")
            if  userType == "2" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EquManagerProfileMenuVC") as! EquManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
            else if userType == "1" {
                let nextVC = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ManagerProfileMenuVC") as! ManagerProfileMenuVC
                self.navigationController?.pushViewController(nextVC, animated: true)
            }
        }
    }
            func TechStatusAPI(){
                APIHandler().getAPIValues(type: TechStatusModel.self, apiUrl: APIList().urlString(url: .techstatus), method: "GET") { Result in
                    switch Result {
                    case .success(let data):
                        print(data)
                        DispatchQueue.main.async {
                        self.techStatus = data
                        print(self.techStatus?.data.count ?? 0)
                        print(self.techStatus?.data ?? "")
                       
                            self.Tableview.reloadData()
                        }
                    case .failure(let error):
                        print(error)
                    }
                }
          }
    

}

extension TechJobAssignVC : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        techStatus?.data.count ?? 0
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "josAssignTabCell", for: indexPath) as! JosAssignTabCell
        
        
        cell.JobID.text     = techStatus?.data[indexPath.row].memberID
        cell.ItemID.text    = techStatus?.data[indexPath.row].itemID
        cell.IssueDate.text = techStatus?.data[indexPath.row].issueDate
        cell.Time.text      = techStatus?.data[indexPath.row].timeLimit
        cell.Status.text    = techStatus?.data[indexPath.row].status
        
//        if let TechStatus = self.TechStatus?.data, indexPath.row < TechStatus.count {
//            cell.JobID?.text     = TechStatus[indexPath.row].memberID
//            cell.ItemID?.text    = TechStatus[indexPath.row].itemID
//            cell.IssueDate?.text = TechStatus[indexPath.row].issueDate
//            cell.Time?.text      = TechStatus[indexPath.row].timeLimit
//            cell.Status?.text    = TechStatus[indexPath.row].status
//
//        } else {
//            cell.JobID?.text = "No data available"
//            cell.ItemID?.text = ""
//            cell.IssueDate?.text = ""
//        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 150
    }
}
